/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tugas.fibonacci;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class TugasFibonacci {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int a, b, c, d;
        
        System.out.print("Masukkan Nilai Fibonacci : ");
        d = input.nextInt();
        
        c=0;
        b=1;
        a=1;
        
        for(int i=0; i<=d; i++){
            if (i==0){
                System.out.println("Nilai ke - 0 adalah " + c);
            }else{
                System.out.println("Nilai ke - " + i + " adalah " + a);
                a=b+c;
                c=b;
                b=a;
                }
            }
    }
    
}
