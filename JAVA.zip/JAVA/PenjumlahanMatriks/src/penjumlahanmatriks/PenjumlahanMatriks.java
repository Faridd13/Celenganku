/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package penjumlahanmatriks;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class PenjumlahanMatriks {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        
        // Meminta input  dari pengguna untuk ukuran Matriks
        System.out.print("Masukkan jumlah baris matriks : ");
        int baris = input.nextInt();
        System.out.print("Masukkan jumlah kolom matriks : ");
        int kolom = input.nextInt();
        
        // Membuat matriks A dan meminta input dari pengguna
        int[][] A = new int[baris][kolom];
        System.out.println("Masukkan elemen matriks A : ");
        for(int i = 0; i < baris; i++){
            for(int j = 0; j < kolom; j++){
                System.out.printf("A[%d][%d] : ", i, j);
                A[i][j] = input.nextInt();
            }
        }
        
        // Membuat matriks B dan meminta input dari pengguna
        int[][] B = new int[baris][kolom];
        System.out.println("Masukkan elemen matriks B : ");
        for(int i = 0; i < baris; i++){
            for(int j = 0; j < kolom; j++){
                System.out.printf("B[%d][%d] : ", i, j);
                B[i][j] = input.nextInt();
            }
        }
        
        // Penjumlahan matriks A dan B
        int[][] C = new int[baris][kolom];
        for(int i = 0; i < baris; i++){
            for(int j = 0; j < kolom; j++){
                C[i][j] = A[i][j] + B[i][j];
            }
        }
        
        // Cetak hasil penjumlahan matriks
        System.out.println("Hasil penjumlahan matriks A dan B adalah : ");
        for(int i = 0; i < baris; i++){
            for(int j = 0; j < kolom; j++){
                System.out.print(C[i][j] + " ");
            }
            System.out.println();
        }
    }
    
}
