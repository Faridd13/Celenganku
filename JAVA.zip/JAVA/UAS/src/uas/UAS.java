/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package uas;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class UAS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        System.out.print("Jumlah deret bilangan : ");
        for(int i=1; i<=10; i++){
            System.out.print(i + ", ");
        }
    }
    
}
