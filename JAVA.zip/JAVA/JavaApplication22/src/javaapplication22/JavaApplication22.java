/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication22;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class JavaApplication22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int hasil = 1, z;
        
        System.out.print("Masukkan bilangan yang mau di Factorialkan : ");
        z = input.nextInt();
        
        for (int j=1; j<z; j++){
            hasil = hasil*j;
        }
        System.out.println("Hasil dari Factorial bilangan "+z+" adalah " +hasil);
    }
    
}
