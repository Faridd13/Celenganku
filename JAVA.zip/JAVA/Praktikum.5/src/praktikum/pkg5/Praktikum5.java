/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum.pkg5;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class Praktikum5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
    int[] data = new int[5];
    int frekuensi;

    // Memasukkan data
    System.out.println("Masukkan 5 angka: ");
    for (int i = 0; i < data.length; i++) {
      data[i] = input.nextInt();
    }

    // Menghitung frekuensi
    for (int i = 0; i < data.length; i++) {
      frekuensi = 0;
      for (int j = 0; j < data.length; j++) {
        if (data[i] == data[j]) {
          frekuensi++;
        }
      }
      System.out.println("number " + data[i]  + " Frekuensi " + frekuensi + " kali.");

      }
    }
}
  