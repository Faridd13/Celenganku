/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikumjava;

/**
 *
 * @author acer
 */
public class PraktikumJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        int angka = 99;
//        int angka2 = 80;
//        
//        if (angka > 90 && angka2 > 70)
//        {
//            System.out.println("True");
//        } else {
//            System.out.println("False");
//        }
        
//        int angka = 5;
//        
//        if (angka > 3)
//        {
//            System.out.println("Angka lebih dari 3");
//        } else {
//            System.out.println("Angka kurang dari 3");
//        }
        
        int jarak = 5;
        String mata = "Tertutup";
        
        if (jarak == 10 && mata == "Tertutup"){
            System.out.println("5 ekor kambing");
        } else if (jarak == 5 && mata == "Tertutup"){
            System.out.println("2 ekor kambing");
        } else if (jarak == 5 && mata == "Terbuka"){
            System.out.println("1 ekor kambing");
        } else {
            System.out.println("False");
        }
        
    }
    
}
