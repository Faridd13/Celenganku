/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikumjava4;

/**
 *
 * @author acer
 */
public class PraktikumJava4 {

//    static int multiply(int number, int number2, int number3){
//        int hasil = number*(number2 + number3);
//        return hasil;
//    }
    
//    yang menggunakan 2
//    static int same(int x,int y){
//        return x+y;
//    }
//    
//    static double same(double x, double y){
//        return x-y;
//    }
    
    static int factorial(int i){
        int hasil = 1;
        for(; i > 0; i--){
            hasil *= i;
        }
        return hasil;
    }
    
    static double tugas(int r, int s){
        double hasil = Math.pow(r, 2)/factorial(s);
        return hasil;
    }
    
    public static void main(String[] args) {
//        int result = multiply(2,5,6);
//        System.out.println(result);
        
//      yang menggunakan 2
//        int result = same(4,4);
//        double result2 = same(4.5,2.3);
//        
//        System.out.println(result);
//        System.out.println(result2);
        
//      hasil factorial
//        int result = factorial(5);
//        System.out.println(result);
        
//      tugasnya
        double result = tugas(2,4);
        System.out.println(result);
        
    }
    
}
