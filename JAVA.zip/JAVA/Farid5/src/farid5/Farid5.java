/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package farid5;

import java.util.Random;

/**
 *
 * @author acer
 */
public class Farid5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [][] val = new int[10][10];
        Random rn = new Random();
        for(int i=0; i<10 ;i++)
        {
            for(int j=0; j<10; j++)
            {
                val[i][j] = rn.nextInt(11);
            }
        }
        
        for(int i=0;i<10;i++)
        {
            for(int j=0; j<10; j++)
            {
                System.out.print(val[i][j]+", ");
            }
            System.out.println();
        }


        int[] tabelFrekuensi = new int[11];

  
        for (int i=0; i<10; i++) {
            tabelFrekuensi[i] = 0;
        }

   
        for (int i=0; i<val.length; i++) {
            for (int j=0; j<val.length; j++){
                tabelFrekuensi[val[i][j]]++;
            }
        }
        
        System.out.println();
        int nilaiModus = 0;
        for (int i=0; i<11; i++) {
            if (tabelFrekuensi[i] > nilaiModus) {
                nilaiModus = i;
            }
        }

        System.out.println("\nModusnya : " + nilaiModus);
        System.out.println("Nilai " + nilaiModus + " muncul sebanyak " + tabelFrekuensi[nilaiModus] + " kali");
    }
    
}
