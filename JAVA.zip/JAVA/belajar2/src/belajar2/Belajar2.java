/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package belajar2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author acer
 */
public class Belajar2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [][] val = new int[10][10];
        Random rn = new Random();
        for(int i=0; i<6;i++)
        {
            for (int j=0;j<=9;j++)
            {
                val[i][j] = rn.nextInt(11);
            }
        }


        for(int i=0;i<6;i++)
        {
            for(int j=0;j<=9;j++)
            {
                System.out.print(val[i][j]+",");
            }
            System.out.println();
        }
    }
    
}
