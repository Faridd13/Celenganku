
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package belajar;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class Belajar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        float hasil = 1, D, P, Q;
        int pangkat1=2, pangkat2=3;
        
        System.out.print("Masukkkan nilai D : ");
        D = input.nextInt();
        
        for (int i=1; i<=pangkat1; i++){
            hasil = hasil * D;
        }
        D = hasil;
        hasil = 1;
        
        System.out.print("Masukkan nilai P : ");
        P = input.nextInt();
        
        for (int j=1; j<=P; j++){
            hasil = hasil * j;
        }
        P = hasil;
        hasil = 1;
        
        System.out.print("Masukkan nilai Q : ");
        Q = input.nextInt();
        
        for (int k=1; k<=pangkat2; k++){
            hasil = hasil * Q;
        }
        Q = hasil;
        hasil = 1;
        
//        System.out.println("Q : " + Q);
        hasil = D + P;
//        System.out.println("hasil : " + hasil);
        hasil = hasil/Q;
        System.out.println("SEMUA HASIL : " + hasil);
    }
    
}
