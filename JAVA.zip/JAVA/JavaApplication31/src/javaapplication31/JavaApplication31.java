/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication31;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class JavaApplication31 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        String nama = "farid danil";
        String[] a = {"anjing","pdi","babi","telek","asu"};
        System.out.println(a[4]);
//        System.out.println(nama);
        
        
        
        
    }
    
}
