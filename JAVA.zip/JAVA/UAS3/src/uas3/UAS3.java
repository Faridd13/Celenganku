/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package uas3;

/**
 *
 * @author acer
 */
public class UAS3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nama = "M. Farid Alwaritsi";
        
        for(int i = 1; i <= 500; i++){
            System.out.println(i + ". " + nama);
        }
    }
    
}
