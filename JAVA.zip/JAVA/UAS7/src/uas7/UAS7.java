/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package uas7;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class UAS7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a, b, hasil = 0;

        System.out.print("Bilangan Pertama : ");
        a = input.nextInt();
        System.out.print("Bilangan Kedua : ");
        b = input.nextInt();

        for (int i = 1; i <= b; i++) {
            hasil += a;
            if (hasil % b == 0) {
                System.out.println("Hasil KPK dari " + a + " dan " + b + " adalah " + hasil);
                break;
            }
        }
    }
    
}
