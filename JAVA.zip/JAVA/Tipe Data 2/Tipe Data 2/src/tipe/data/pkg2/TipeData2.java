/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tipe.data.pkg2;

import java.util.Scanner;

/**
 *
 * @author HP
 */
public class TipeData2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {



        // Membuat objek Scanner untuk membaca input dari pengguna
        Scanner scanner = new Scanner(System.in);
        
        // Meminta pengguna memasukkan nilai untuk variabel
        System.out.print("Masukkan nilai integer: ");
        int i = scanner.nextInt();
        System.out.print("Masukkan nilai double: ");
        double d = scanner.nextDouble();
        System.out.print("Masukkan nilai boolean (true/false): ");
        boolean b = scanner.nextBoolean();
        System.out.print("Masukkan sebuah karakter: ");
        char c = scanner.next().charAt(0);
        System.out.print("Masukkan sebuah string: ");
        String s = scanner.next();
        
        // Konversi tipe data
        double d2 = i;          // konversi dari int ke double
        int i2 = (int) d;       // konversi dari double ke int
        String s2 = Integer.toString(i);  // konversi dari int ke String
        char c2 = s.charAt(0);  // mengambil karakter pertama dari String s
        boolean b2 = Boolean.parseBoolean("false");  // konversi dari String ke boolean
        
        // Menampilkan hasil konversi
        System.out.println("i = " + i + ", tipe data: " + Integer.TYPE);
        System.out.println("d = " + d + ", tipe data: " + Double.TYPE);
        System.out.println("b = " + b + ", tipe data: " + Boolean.TYPE);
        System.out.println("c = " + c + ", tipe data: " + Character.TYPE);
        System.out.println("s = " + s + ", tipe data: " + s.getClass());
        System.out.println("d2 = " + d2 + ", tipe data: " + Double.TYPE);
        System.out.println("i2 = " + i2 + ", tipe data: " + Integer.TYPE);
        System.out.println("s2 = " + s2 + ", tipe data: " + s2.getClass());
        System.out.println("c2 = " + c2 + ", tipe data: " + Character.TYPE);
        System.out.println("b2 = " + b2 + ", tipe data: " + Boolean.TYPE);
        
        // Menutup objek Scanner
        scanner.close();
    }
}

    

    