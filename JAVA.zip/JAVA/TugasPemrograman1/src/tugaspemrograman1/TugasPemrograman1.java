/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tugaspemrograman1;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class TugasPemrograman1 {

    public static void permen(int jumlahPermen, int jumlahAnak){
        int permenPerAnak = jumlahPermen / jumlahAnak;
        int sisaPermen = jumlahPermen % jumlahAnak;
        
        System.out.println("Setiap anak akan mendapatkan " + permenPerAnak + " permen");
        if(sisaPermen > 0){
            System.out.println("Sisa " + sisaPermen + " permen akan dihancurkan bersama");
        }
    }
    
    public static void main(String[] args) {
        int jumlahPermen;
        int jumlahAnak;
        Scanner input = new Scanner (System.in);
        
        System.out.print("Masukkan Jumlah Permen : ");
        jumlahPermen = input.nextInt();
        System.out.print("Masukkan Jumlah Anak : ");
        jumlahAnak = input.nextInt();
        
        permen(jumlahPermen,jumlahAnak);
        
    }
}
