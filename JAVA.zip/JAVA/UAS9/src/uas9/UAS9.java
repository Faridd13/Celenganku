/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package uas9;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class UAS9 {

    /**
     * @param args the command line arguments
     */
    public static void prima(int a) {
        boolean prima = true;
        for (int i = 2; i <= a / 2; i++) {
            if (a % i == 0) {
                prima = false;
                break;
            }
        }
        if (prima) {
            System.out.println(a + " Adalah bilangan Prima");
        } else {
            System.out.println(a + " Bukan bilangan Prima");
        }
    }

    public static void main(String[] args) {
        int a;
        Scanner input = new Scanner(System.in);
        
        System.out.print("Masukkan Angka prima anda : ");
        a = input.nextInt();
        prima(a);
    }
}