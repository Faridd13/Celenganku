/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package permen;

import java.util.Scanner;


public class Permen {

    public static void permen(int a, int b){
        int permenPerAnak = a / b;
        int sisaPermen = a % b;
        
        System.out.println("Setiap anak akan mendapatkan " + permenPerAnak + " permen");
        if(sisaPermen > 0){
            System.out.println("Sisa " + sisaPermen + " permen akan dihancurkan bersama");
        }
    }

    public static void main(String[] args) {
        
        permen(13,4);
        
    }
}

    