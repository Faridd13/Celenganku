/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package farid2;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class Farid2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        int Umur, Tl;
        String Nama, Alamat;
        
        System.out.println ("Siapakah nama anda?");
        Nama = input.next();
        System.out.println ("Dimanakah alamat anda?");
        Alamat = input.next();
        System.out.println ("Berapakah umur anda?");
        Umur = input.nextInt();
        System.out.println ("Berapakah tanggal lahir anda?");
        Tl = input.nextInt();
        System.out.println ("nama anda adalah " + Nama );
        System.out.println ("Alamat anda adalah " + Alamat );
        System.out.println ("umur anda adalah " + Umur );
        System.out.println ("tanggal lahir anda adalah " + Tl );
        
        
        
        // TODO code application logic here
    }
    
}
