/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package otodidak;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class Otodidak {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i, j, k, m, n, p, q, jumlah;
        jumlah = 0
        int matriks1[][] = new int[][];
        int matriks2[][] = new int[][];
        int hasil[][] = new int[][];
        Scanner input = new Scanner(System.in);
        
        System.out.print("Masukkan jumlah baris matriks pertama: ");
        m = input.nextInt();
        System.out.print("Masukkan jumlah kolom matriks pertama: ");
        n = input.nextInt();
        
        System.out.print("Masukkan jumlah baris matriks kedua: ");
        p = input.nextInt();
        System.out.print("Masukkan jumlah kolom matriks kedua: ");
        q = input.nextInt();
        
        if (n != p) {
            System.out.println("Matriks tidak dapat dikalikan satu sama lain.\n");
        } else {
            System.out.println("Masukkan elemen matriks pertama: ")
            for (i = 0; i < m; i++) {
                for (j = 0; j < n; j++) {
                    matriks1[i][j] = input.nextInt();
                }
            }
            
            System.out.printfn("Masukkan elemen matriks kedua: ");
            for (i = 0; i < p; i++) {
                for (j = 0; j < q; j++) {
                    matriks2[i][j] = input.nextInt();
                }
            }
            
            for (i = 0; i < m; i++) {
                for (j = 0; j < q; j++) {
                    for (k = 0; k < p; k++) {
                        jumlah = jumlah + matriks1[i][k] * matriks2[k][j];
                    }
                    hasil[i][j] = jumlah;
                    jumlah = 0;
                }
            }
            
            System.out.println("Hasil perkalian matriks: ");
            for (i = 0; i < m; i++) {
                for (j = 0; j < n; j++) {
                    System.out.print(hasil[i][j] + "\t");
                }
                System.out.println();
            }
        }
    }
    
}
