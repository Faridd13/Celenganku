/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikumjava2;

/**
 *
 * @author acer
 */
public class PraktikumJava2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
//        int i;
//        for(i = 1; i < 5; i++){
//            System.out.println("Angka : "+i);
//        }
        
//        int i = 1;
//        while(i < 8){
//            System.out.println("While ke : "+i);
//            i++;
//            if(i == 3){
//                System.out.println("Stop Loop");
//                break;
//            }
//        }
        
//        for(int k = 0; k < 3; k++){
//            System.out.print("k");
//            for(int j = 1; j < 4; j++){
//                System.out.print("j");
//            }
//            System.out.println("");
//        }
        
        for(int i = 1; i <= 4; i++){
            System.out.print(i + " pangkat " +i+ " = ");
            int hasil = 1;
            for(int j = 1; j <= i; j++){
                hasil *=i;
            }
            System.out.println(" "+ hasil +" ");
        }
    }
}
    
