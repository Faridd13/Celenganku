/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tugaspemrograman;

/**
 *
 * @author acer
 */
public class TugasPemrograman {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String data1 = "100";
        String data2 = "200";
        String data3 = "45.50";
        
        byte a = Byte.valueOf(data1);
        short b = Short.parseShort(data1);
        int c = Integer.parseInt(data2);
        long d = Long.valueOf(data2);
        
        float e = Float.valueOf(data3);
        double f = Double.parseDouble(data3);
        
        System.out.println("Konversi Dari String Ke Tipe Data Lainnya");
        System.out.println("=========================================");
        System.out.println();
        System.out.println("Test Konversi Byte: "+a / 2);
        System.out.println("Test Konversi Short: "+b * 2);
        System.out.println("Test Konversi Int: "+c / 10);
        System.out.println("Test Konversi Long: "+d * 100);
        System.out.println("Test Konversi Float: "+e / 4);
        System.out.println("Test Konversi Double: "+f * 15.50);
    }
}
