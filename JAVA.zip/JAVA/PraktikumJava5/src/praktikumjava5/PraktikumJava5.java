/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikumjava5;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author acer
 */
public class PraktikumJava5 {

//    public static int plus(int [] nilai){
//        int i, total = 0;
//        for(i=0; i<10; i++){
//            total = total + nilai[i];
//        }
//        return total;
//    }
    static int [] sort(int [] arr){
        Arrays.sort(arr);
        return arr;
    }
    
//    static int [] frekuensi(int [] arr){
//        for(int i=0; i<arr.length; i++){
//            System.out.println(arr[i]);
//        }
//        return arr;
//    }
    
    
    public static void main(String[] args) {
//        Scanner reply = new Scanner(System.in);
//        int [] Angka = new int [10];
//        int i;
//        int jumlah = 0;
//        for(i=0; i<5; i++){
//            System.out.print("Masukkan angka : ");
//            Angka[i] = reply.nextInt();
//        }
//        jumlah = plus(Angka);
//        System.out.println(jumlah);
        
        int [] awal = {8,4,1,2};
        int [] hasil = sort(awal);
        System.out.println(Arrays.toString(hasil));
          
        
    }
    
}
