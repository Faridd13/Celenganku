/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikumjava3;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class PraktikumJava3 {

//    static void hi(){
//        System.out.println("Hallo Deks");
//    }
//    
//    static void greeting(String name){
//        System.out.println("Good Morning "+name);
//    }
//    
//    static void luasLingkaran(int diameter){
//        double hasil = Math.PI * Math.pow((diameter/2), 2);
//        System.out.println("Luas lingkaran dengan diameter " +diameter +" = "+hasil);
//    }
    
    static void prima(int a) {
        boolean prima = true;
        for (int i = 2; i <= a / 2; i++) {
            if (a % i == 0) {
                prima = false;
                break;
            }
        }
        if (prima) {
            System.out.println(a + " Adalah Bilangan Prima");
        } else {
            System.out.println(a + " Bukan Bilangan Prima");
        }
    }
    
    public static void main(String[] args) {
//        hi();
//        greeting("Udin");
//        luasLingkaran(14);

//output prima secara input  
//        int a;
//        Scanner input = new Scanner(System.in);
//        
//        System.out.print("Masukkan Bilangan Prima Anda : ");
//        a = input.nextInt();
//        prima(a);
        
//output prima secara langsung
        prima(4);
        
//Method nya menggunakan private bukan menggunakan static
//        PraktikumJava3 z = new PraktikumJava3();
//        z.prima(a);
    }
    
}


//class farid{
//    public static void main(String[] args) {
//data kembalian dibeda kelas
//        PraktikumJava3.prima(0);
//    }
//}
