/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package farid4;

import java.util.Random;

/**
 *
 * @author acer
 */
public class Farid4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [] val = new int[10];
        Random rn = new Random();
        for(int i=0; i<10 ;i++)
        {
                val[i] = rn.nextInt(10) + 1;
        }
        for(int i=0;i<10;i++)
        {
            System.out.print("," + val[i]);
        }


        int[] tabelFrekuensi = new int[11];

  
        for (int i=0; i<10; i++) {
            tabelFrekuensi[i] = 0;
        }

   
        for (int i=0; i<val.length; i++) {
            tabelFrekuensi[val[i]]++;
        }

  
        int nilaiModus = 0;
        for (int i=0; i<10; i++) {
            if (tabelFrekuensi[i] > nilaiModus) {
                nilaiModus = i;
            }
        }

        System.out.println("\nModusnya : " + nilaiModus);
        System.out.println("Nilai " + nilaiModus + " muncul sebanyak " + tabelFrekuensi[nilaiModus] + " kali");
    }

}

    

