/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package perkalianskalar;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class PerkalianSkalar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        
        System.out.print("Masukkan urutan matriks: ");
        int n = input.nextInt();
        System.out.print("Masukkan skalar: ");
        int skalar = input.nextInt();
        
        int[][] matriks = new int[n][n];
        
        System.out.println("Masukkan elemen matriks: ");
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                matriks[i][j] = input.nextInt();
            }
        }
        
        int[][]result = new int[n][n];
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                result[i][j] = skalar * matriks[i][j];
            }
        }
        
        System.out.println("Hasil perkalian matriks dengan skalar " + skalar + " adalah: ");
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                System.out.print(result[i][j] + " ");
            }
            System.out.println();
        }
    }
    
}
